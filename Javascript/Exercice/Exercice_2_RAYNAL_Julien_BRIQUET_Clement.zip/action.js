$("#c1").on("click", caseOnClick1);
$("#c2").on("click", caseOnClick2);
$("#c3").on("click", caseOnClick3);
$("#c4").on("click", caseOnClick4);
$("#c5").on("click", caseOnClick5);
$("#c6").on("click", caseOnClick6);
$("#c7").on("click", caseOnClick7);
$("#c8").on("click", caseOnClick8);
$("#c9").on("click", caseOnClick9);

$("#resetButton").on("click", buttonOnClick);

let player = true;
let score1 = 0;
let score2 = 0;

function caseOnClick1(){
    updateCase("c1");
}

function caseOnClick2(){
    updateCase("c2");
}

function caseOnClick3(){
    updateCase("c3");
}

function caseOnClick4(){
    updateCase("c4");
}

function caseOnClick5(){
    updateCase("c5");
}

function caseOnClick6(){
    updateCase("c6");
}

function caseOnClick7(){
    updateCase("c7");
}

function caseOnClick8(){
    updateCase("c8"); 
}

function caseOnClick9(){
    updateCase("c9");
}

function updateCase(value){
    if($("#" + value).text() == "..."){
        switch(player){
            case true:
                $("#" + value).text("X");
                break; 

            case false:
                $("#" + value).text("O");
                break;
        }
        winCondition();
        player = !player;
    }
}

function winCondition(){
    let token;

    switch(player){
        case true :
            token = "X";
            break;

        case false :
            token = "O";
            break;
    }

    if($("#c1").text() == token && $("#c2").text() == token && $("#c3").text() == token){
        winUpdate();
        return;
    }
    
    if($("#c1").text() == token && $("#c4").text() == token && $("#c7").text() == token){
        winUpdate();
        return;
    }    

    if($("#c1").text() == token && $("#c5").text() == token && $("#c9").text() == token){
        winUpdate();
        return;
    }

    if($("#c2").text() == token && $("#c5").text() == token && $("#c8").text() == token){
        winUpdate();
        return;
    }

    if($("#c4").text() == token && $("#c5").text() == token && $("#c6").text() == token){
        winUpdate();
        return;
    }

    if($("#c7").text() == token && $("#c8").text() == token && $("#c9").text() == token){
        winUpdate();
        return;
    }

    if($("#c3").text() == token && $("#c6").text() == token && $("#c9").text() == token){
        winUpdate();
        return;
    }

    if($("#c3").text() == token && $("#c5").text() == token && $("#c7").text() == token){
        winUpdate();
        return;
    }

    if($(".case:contains('...')").length == 0){
        console.log("oui");
        $(".case").text("...");
        $("#winnerHeader").text("Egalité !");
    }
}

function winUpdate(){
    switch(player){
        case true :
            score1 += 1;
            $("#score1").text(score1);
            $("#winnerHeader").text("Joueur 1 !");
            break;

        case false :
            score2 += 1;
            $("#score2").text(score2);
            $("#winnerHeader").text("Joueur 2 !");
            break;
    }
    $(".case").text("...");
}

function buttonOnClick(){
    $(".case").text("...");
    $(".score").text(0);
    $("#winnerHeader").text("1ère Partie");
    player = true;
    score1 = 0;
    score2 = 0;
}